#include <iostream>
using namespace std;

int main() {
  // Write your code for problem 1 below.
  int var1 = 50;
	int var2 = 100;
	int sum = var1 + var2;
	cout << sum << endl;
	
  // Write your code for problem 2 below.
	float percentage = 0.58;
	float profit = 8600000.0;
	cout << int(percentage * profit) << endl;

  // Write your code for problem 3 below.
	float price = 95.0;
	float stateST = 0.04;
	float countryST = 0.02;
	float finalST = (price * stateST) + (price * countryST);
	cout << finalST << endl;

  // Write your code for problem 4 below.
	float mealCharge = 90.0;
	float mealTax = 0.08;
	float tip = 0.2;
	float taxAmount = mealCharge * mealTax;
	float tipAmount = (mealCharge + taxAmount) * tip;
	float totalBill = mealCharge + taxAmount + tipAmount;
	cout 
	<< mealCharge << endl 
	<< taxAmount << endl
	<< tipAmount << endl
	<< totalBill << endl;

  // Write your code for problem 5 below.
	int a = 28, b = 32, c = 37, d = 24, e = 34;
	float sum1 = a + b + c + d + e;
	float avg = sum1/5;
	cout << avg << endl;

  // Write your code for problem 6 below.
	// payAmount, payPeriods, AnnualPay
	float payAmount = 2200.0;
	int payPeriods = 26;
	float AnnualPay;
	AnnualPay = payAmount * payPeriods;
	cout << AnnualPay << endl;

  // Write your code for problem 7 below.
	/*Price of item 1: $15.95
ii. Price of item 2: $24.95
iii. Price of item 3: $6.95
iv. Price of item 4: $12.95
v. Price of item 5: $3.95 */
	float f = 15.95, g = 24.95, h = 6.95, i = 12.95, j = 3.95;
	float subTotal = f + g + h + i + j;
	float saleTax = subTotal * 0.07;
	float finalTotal = subTotal + saleTax;
	cout
	<< f << endl
	<< g << endl
	<< h << endl
	<< i << endl
	<< j << endl
	<< subTotal << endl
	<< saleTax << endl
	<< finalTotal << endl;

}